import api from "./api";

export interface UsuarioAcesso {
  id: number;
  nome: string;
  nomeUsuario: string;
  perfil: "ADMIN" | "ESTOQUISTA" | "CONSULTA";
  ativo: boolean;
  trocarSenha: boolean;
  dataCriacao?: string;
}

export interface LoginResposta {
  token: string;
  tipo: string;
  expiraEmSegundos: number;
  trocarSenha: boolean;
  usuario: UsuarioAcesso;
}

function salvarUsuario(usuario: UsuarioAcesso) {
  sessionStorage.setItem("erp_usuario", JSON.stringify(usuario));
}

export async function login(
  nomeUsuario: string,
  senha: string
): Promise<LoginResposta> {
  // Remove apenas a sessão anterior.
  sessionStorage.removeItem("erp_token");
  sessionStorage.removeItem("erp_usuario");
  localStorage.removeItem("erp_token");

  // Login público: não deve enviar o token antigo.
  const resposta = await api.post<LoginResposta>(
    "/auth/login",
    { nomeUsuario, senha },
    {
      headers: {
        Authorization: undefined,
      },
    }
  );

  const dados = resposta.data;

  if (!dados.token || !dados.usuario) {
    throw new Error("A API não retornou o token ou os dados do usuário.");
  }

  // Salva o token que será usado nas requisições protegidas.
  sessionStorage.setItem("erp_token", dados.token);
  salvarUsuario(dados.usuario);

  return dados;
}

export async function alterarSenha(
  senhaAtual: string,
  novaSenha: string
): Promise<void> {
  const token = sessionStorage.getItem("erp_token");

  if (!token) {
    throw new Error(
      "Sessão não encontrada. Faça login novamente para alterar a senha."
    );
  }

  // Envia explicitamente o token JWT.
  await api.post(
    "/auth/alterar-senha",
    { senhaAtual, novaSenha },
    {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
  );

  // Atualiza os dados locais após o sucesso da API.
  try {
    const response = await api.get<UsuarioAcesso>("/auth/me", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    salvarUsuario(response.data);
  } catch {
    // A API documentada retorna 204 quando a senha é alterada.
    // Se a consulta do perfil falhar, atualiza somente o estado local.
    const usuario = obterUsuario();

    if (usuario) {
      salvarUsuario({ ...usuario, trocarSenha: false });
    }
  }
}

export function sair(): void {
  sessionStorage.removeItem("erp_token");
  sessionStorage.removeItem("erp_usuario");
  localStorage.removeItem("erp_token");
}

export function obterUsuario(): UsuarioAcesso | null {
  const raw = sessionStorage.getItem("erp_usuario");

  if (!raw) return null;

  try {
    return JSON.parse(raw) as UsuarioAcesso;
  } catch {
    return null;
  }
}
